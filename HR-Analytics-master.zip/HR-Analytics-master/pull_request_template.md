# please take some beginner tutorials for colabs before jumping onto it.
# ignore mounting of drive onto colabs if not using it.
